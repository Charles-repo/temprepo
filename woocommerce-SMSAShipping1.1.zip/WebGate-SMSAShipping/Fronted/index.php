<?php
    
//    add_filter('woocommerce_cart_needs_payment' , '__return_false');
    
    add_action('woocommerce_thankyou_order_id' , function($order_id){
        
        
        // get order details data...
        $order = new WC_Order($order_id);
        $WebGate_Shipping_Method = new WebGate_Shipping_Method();
        $dataHelper = optional($WebGate_Shipping_Method->settings);
        $shipping_methods = $order->get_shipping_method();
        $payment_method = $order->get_payment_method();
        
        if($shipping_methods == $dataHelper->title)
        {
            $order->update_meta_data('_shipping_method_awb' , 'webgate_method');
            $order->save();
            
            $SMSA = new SMSA();
            
            $customer_name = $order->get_shipping_first_name() . ' ' . $order->get_shipping_last_name();
            $currency_code = $order->get_currency();
            $currency_symbol = get_woocommerce_currency_symbol($currency_code);
            
            $weight = 0;
            foreach($order->get_items() as $item)
            {
                $_weight = get_post_meta($item->get_data()['product_id'] , '_weight' , true);
                if($_weight)
                {
                    $weight += $_weight * $item->get_quantity();
                }
            }
            
            
            $data = [
                'passKey' => optional($WebGate_Shipping_Method->settings)->passkey ,
                'refNo' => $order->get_id() ,
                'sentDate' => date('Y-m-d H:i:s') ,
                'idNo' => $order->get_id() ,
                'cName' => $customer_name ,
                'cntry' => $order->get_shipping_country() , // 'Riyadh'
                'cCity' => $order->get_shipping_city() ,
                'cZip' => $order->get_shipping_postcode() ,
                'cPOBox' => $order->get_shipping_postcode() ,
                'cMobile' => $order->get_billing_phone() ,
                'cTel1' => $order->get_billing_phone() ,
                'cTel2' => '' ,
                'cAddr1' => $order->get_shipping_address_1() ,
                'cAddr2' => $order->get_shipping_address_2() ,
                'shipType' => 'DLV' ,
                'PCs' => $order->get_item_count() ,
                'cEmail' => $order->get_billing_email() ,
                'carrValue' => '' ,
                'carrCurr' => $currency_symbol ,
                'codAmt' => $payment_method == 'cod' ? $order->get_total() : '0' ,
                'weight' => $weight ,
                'custVal' => '' ,
                'custCurr' => $currency_code ,
                'insrAmt' => '' ,
                'insrCurr' => '' ,
                'itemDesc' => '' ,
                'sName' => $dataHelper->shipper_name ,
                'sContact' => $dataHelper->shipper_contact ,
                'sAddr1' => $dataHelper->sipper_address ,
                'sAddr2' => '' ,
                'sCity' => $dataHelper->shipper_city ,
                'sPhone' => $dataHelper->shipper_phone ,
                'sCntry' => $dataHelper->shipper_country ,
                'prefDelvDate' => '' ,
                'gpsPoints' => '' ,
            ];
            
            
            $log_data = [
                'order_id' => $order->get_Id() ,
                'customer_id' => $order->get_customer_id() ,
                'customer_name' => $customer_name ,
            ];
            
            // send data soap
            $addShipMPS = $SMSA->addShipMPS($data);
            if($addShipMPS instanceof Exception)
            {
                // submit log
                wp_insert_post([
                    'post_type' => 'webgate_log_smsa' ,
                    'post_excerpt' => $addShipMPS->getMessage() ,
                    'meta_input' => $log_data ,
                ]);
            }
            else
            {
                // set awd_number order
                if(is_numeric($addShipMPS->addShipMPSResult))
                {
                    // get status
                    $awd_status = $SMSA->getStatus($addShipMPS->addShipMPSResult);
                    $order->update_meta_data('awb_number' , $addShipMPS->addShipMPSResult);
                    $order->update_meta_data('awb_status' , ($awd_status instanceof Exception) ? '' : $awd_status);
                    $order->save_meta_data();
                }
                
                // submit log
                wp_insert_post([
                    'post_type' => 'webgate_log_smsa' ,
                    'post_excerpt' => $addShipMPS->addShipMPSResult ,
                    'meta_input' => $log_data ,
                ]);
                
            }
            
            
        }
    } , 10);
    
    
    //    add_action( 'all', function ( $tag ) {
    //        echo "<pre>" . $tag . "</pre>";
    //    } );
    
    
    // Add a custom metabox only for shop_order post type (order edit pages)
    add_action('woocommerce_order_details_after_customer_details' , function(){
        $order_id = optional($_GET,get_query_var('view-order'))->{'view-order'};
        
        if(get_post_meta($order_id , '_shipping_method_awb' , true) == 'webgate_method')
        {
            require __DIR__ . '/view.php';
            awb_admin_message_clear();
        }
    });
    